#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "assert.h"
//--------------

char* stringDuplicator(char* s, int times){
    //--1-- wrong expression
    assert(s);
    assert(times > 0);
    //convention 1 -- CAPS
    int len = strlen(s);
    //--2-- malloc for string need +1 for '\0' char
    char* out = malloc(len*times + 1);
    //--3-- assert for needed check, using if instead
    //assert(out);
    if(!out) {
        free(out);
        return NULL;
    }
    //--4-- <= results in to many loops
    //convention 2 -- no tabs inside for loop
    for (int i=0; i<times; i++){
        //--5-- wrong order;
        strcpy(out,s);
        out = out + len;
    }
    //--6-- out points to the end of the string it needs to be brought back
    return out - len * times;
}
